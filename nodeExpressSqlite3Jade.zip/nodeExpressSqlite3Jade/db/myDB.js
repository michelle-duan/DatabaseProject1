var sqlite3 = require("sqlite3").verbose();
const util = require("util");

function myDB() {
  const myDB = {};

  const getDb = () => new sqlite3.Database("./db/Course.db");

  myDB.getSongs = function (page) {
    const db = getDb();

    const PAGE_SIZE = 10;
    const query = `SELECT TrackId, nuid, course_id
      FROM course_registration
      LIMIT ${PAGE_SIZE} OFFSET ${PAGE_SIZE * (page - 1)};`;

    const allPromise = util.promisify(db.all.bind(db));

    return allPromise(query).finally(() => {
      console.log("done, closing");
      db.close();
    });
  };

  myDB.createSong = function (song) {
    const db = getDb();

    const query = `
    INSERT INTO course_registration(nuid, course_id)
VALUES($Name, $Milliseconds);`;

    const runPromise = util.promisify(db.run.bind(db));

    return runPromise(query, song).finally(() => db.close());
  };

  myDB.updateSong = function (song) {
    const db = getDb();

    const query = `
    UPDATE course_registration
    SET
      nuid = $Name,
      course_id = $Milliseconds,
    WHERE
      TrackId = $TrackId`;

    const runPromise = util.promisify(db.run.bind(db));

    return runPromise(query, {
      $TrackId: +song.$TrackId,
      $Name: song.$Name,
      $Milliseconds: +song.$Milliseconds,
      $MediaTypeId: 1,
      $UnitPrice: 1.1,
    })
      .then(() => db)
      .finally(() => db.close());
  };

  myDB.deleteSong = function (songId) {
    const db = getDb();

    const query = `
    DELETE FROM course_registration WHERE trackId==$trackId;`;

    return new Promise((resolve, reject) => {
      db.run(
        query,
        {
          $trackId: songId,
        },
        function (err) {
          if (err) {
            return reject(err);
          }

          return resolve({ lastID: this.lastID, changes: this.changes });
        }
      );
    });

    // const runPromise = util.promisify(db.run.bind(db));

    // return runPromise(query, {
    //   $trackId: songId,
    // }).finally(() => db.close());
  };

  return myDB;
}

module.exports = myDB();
