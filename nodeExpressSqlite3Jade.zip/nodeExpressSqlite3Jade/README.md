# nodeExpressSqlite3Jade

A basic example showcasing an sqlite3 Database with server side rendering

## Installation

Clone the repository, then

```
cd nodeExpressSqlite3Jade

npm install
npm run start
```

And your app should be running on http://localhost:3000
